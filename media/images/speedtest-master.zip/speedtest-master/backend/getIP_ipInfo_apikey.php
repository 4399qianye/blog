<?php

// put your token between the quotes if you have one
$IPINFO_APIKEY = '';
